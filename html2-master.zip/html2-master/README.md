# HTML & CSS Exercise 2

Solutions for this exercise can be found by switching to the `solution` branch, like this:
![Solution Branch](READMEpic.png)
